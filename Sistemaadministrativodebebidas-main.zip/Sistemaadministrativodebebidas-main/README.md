
  # Sistema Administrativo de Bebidas

  This is a code bundle for Sistema Administrativo de Bebidas. The original project is available at https://www.figma.com/design/nv7WjTON7itDpUFgdgUJbz/Sistema-Administrativo-de-Bebidas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  